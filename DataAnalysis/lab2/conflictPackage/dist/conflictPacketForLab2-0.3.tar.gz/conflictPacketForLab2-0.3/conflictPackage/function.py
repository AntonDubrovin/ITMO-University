def f():
    print("Print in function for lab2 :)")