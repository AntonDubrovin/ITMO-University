const lmsConfig = require('@yandex-lms-ext/prettier-config');

module.exports = {
  ...lmsConfig
};
